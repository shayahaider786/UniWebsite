

<?php $__env->startSection('content'); ?>

        <!-- Page Header End -->
        <div class="container-xxl py-5 page-header position-relative mb-5">
            <div class="container py-5">
                <h1 class="display-2 text-white animated slideInDown mb-4">Events</h1>
                <nav aria-label="breadcrumb animated slideInDown">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">Events</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End -->


        <!-- About Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-12 wow fadeInUp" data-wow-delay="0.1s">
                        <h1 class="mb-4 text-center">Events</h1>
                        

                        <div class="row">
                            <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-4 mb-4 pt-3"> <!-- Adjust size as per your design -->
                                    <a href="<?php echo e(route('eventsById' , $event->id)); ?>">
                                        <div class="card">
                                            <img src="<?php echo e($event->image_urls[0]); ?>" class="card-img-top" alt="Event Image" height="300px">
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo e($event->name); ?></h5>
                                                <p class="card-text text-dark"><?php echo e(Str::limit($event->description, 40)); ?></p>
                                                <div class=" d-flex justify-content-between">
                                                    <p class="text-secondary"><strong>Date:</strong> <?php echo e(\Carbon\Carbon::parse($event->event_date)->format('M d, Y')); ?></p>
                                                    <p class="text-secondary"><strong>Time:</strong> <?php echo e(\Carbon\Carbon::parse($event->event_time)->format('h:i A')); ?></p> <!-- Format for 12-hour time with AM/PM -->                                            
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p>There are no event</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About End -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.appTwo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shayanProject\UniWebsite\resources\views/frontend/events.blade.php ENDPATH**/ ?>