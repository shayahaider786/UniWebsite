

<?php $__env->startSection('content'); ?>

        <!-- Page Header End -->
        <div class="container-xxl py-5 page-header position-relative mb-5">
            <div class="container py-5">
                <h1 class="display-2 text-white animated slideInDown mb-4">Shining Start</h1>
                <nav aria-label="breadcrumb animated slideInDown">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">Shining Start</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End -->


        <!-- About Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <h2 class="text-center">Shining Stars</h2>
                <div class="row">
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex align-items-center justify-content-evenly mt-5">
                        <div class="w-25">
                            <img src="<?php echo e(asset('/' . $student->image)); ?>" width="60%" class="rounded" alt="<?php echo e($student->name); ?>">
                        </div>
                        <div class="w-75">
                            <h3><?php echo e($student->name); ?></h3>
                            <p><?php echo e($student->description); ?></p>
                            <h4>Marks <?php echo e($student->marks); ?></h4>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </div>
        </div>
        <!-- About End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.appTwo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shayanProject\UniWebsite\resources\views/frontend/studentStar.blade.php ENDPATH**/ ?>