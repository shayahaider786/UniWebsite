

<?php $__env->startSection('content'); ?>

<!-- Page Header Start -->
<div class="container-xxl py-5 page-header position-relative mb-5">
    <div class="container py-5">
        <h1 class="display-2 text-white animated slideInDown mb-4">Gallary</h1>
        <nav aria-label="breadcrumb animated slideInDown">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                <li class="breadcrumb-item text-white active" aria-current="page">Gallary</li>
            </ol>
        </nav>
    </div>
</div>
<!-- Page Header End -->

<!-- Administration Person Details Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-5 align-items-center">
            <h1 class="mb-4 text-center">Gallary</h1>
                <?php $__currentLoopData = $gallaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4">
                        <a href="<?php echo e(asset('storage/' . $gallary->image_path)); ?>" data-lightbox="gallery" data-title="Portfolio Image">
                            <img src="<?php echo e(asset('storage/' . $gallary->image_path)); ?>" class="card-img-top rounded" alt="gallery Image" width="100%" height="300px">
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!-- Administration Person Details End -->

<script>
    lightbox.option({
        'resizeDuration': 200,
        'wrapAround': true, // Allows continuous sliding
        'alwaysShowNavOnTouchDevices': true
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.appTwo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shayanProject\UniWebsite\resources\views/frontend/gallary.blade.php ENDPATH**/ ?>