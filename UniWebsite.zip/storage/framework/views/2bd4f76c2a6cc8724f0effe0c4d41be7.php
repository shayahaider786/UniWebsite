

<?php $__env->startSection('content'); ?>

        <!-- Carousel Start -->
        
        <!-- Carousel End -->

        <!-- About Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-12 wow  fadeInUp" data-wow-delay="0.1s">
                        <h1 class="mb-4">Welcome to the start of your journey</h1>
                        <div class="row mt-4">
                            <div class="col-md-7 mt-2">
                                <img src="frontend/img/assets/img5.png" class="img-fluid rounded" width="100%" alt="">
                            </div>
                            <div class="col-md-5 mt-2">
                                <p class="mb-3 alignPara fs-5 px-3">
                                    Since 1998, SEC has been committed to academic excellence and holistic development, fostering an environment where every student’s unique potential is recognized and nurtured. As the principal, I am honored to lead a school that goes beyond academics to inspire creativity, resilience, and a lifelong passion for learning.

                                    At SEC, we believe education is not just about achieving academic success but also about building character and a strong sense of purpose. Our goal is to help students embrace challenges, grow with confidence, and emerge as compassionate, well-rounded individuals ready to make a positive impact in the world.

                                    As you begin this journey with us, know that SEC is more than just a school—it’s a community dedicated to your growth and success. Together, we will create a future filled with opportunities and achievements. Welcome to SEC, where your journey of transformation begins!                               
                                </p>
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About End -->

        <!-- pricipal message  Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-12 wow  fadeInUp" data-wow-delay="0.1s">
                        <h1 class="mb-4">Principal Message</h1>
                        <div class="row mt-4">
                            <div class="col-md-8 mt-2">
                                <p class="mb-3 alignPara">
                                    Welcome to SEC, where we have been committed to academic excellence and holistic development since 1998. As principal, I am honored to lead a school that values each student's unique potential and strives to provide a nurturing environment where they can flourish both academically and personally. At SEC, we believe that education is not just about academic success but also about building character, resilience, and a strong sense of purpose.
                                </p>
                                <p class="mb-3 alignPara">
                                    Sharif Education complex is a unique educational project in providing extraordinary care and education with a sense of ownership to the students. It has completed its 26 academic years obtaining very good results and achieving its mission. The mission of the school is to educate and train the generation making them right spirited Muslims and Pakistani citizens. During the education, necessary emphasis is laid on the character building and personality development of the students. The curriculum, thus, includes a broad and well-planned program for academic, mental and physical training of the students which will enable them to adopt any profession in life.
                                </p>
                                <p class="mb-3 alignPara">
                                    Thank you for entrusting us with your child’s education. Together, as a community of students, parents, and teachers, we aim to make their educational journey enriching and impactful. We look forward to a bright future with you as part of the SEC family.
                                </p>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="d-flex align-items-center">
                                            <div class="">
                                                <h6 class="text-primary mb-1">Warm regards,</h6>
                                                <small>Muhammad Ashfaq</small><br>
                                                <small>Principal, SEC</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mt-2">
                                <img src="frontend/img/assets/pricipleImg.png" class="img-fluid rounded" width="100%" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- pricipal message  end -->

        <!-- About Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                        <h1 class="mb-4">Learn More About Our Work And Our Cultural Activities</h1>
                        <p>Our initiatives focus on both educational excellence and fostering a rich cultural environment. We offer a variety of cultural activities, including performances, workshops, and events that celebrate creativity and diversity. </p>
                        <p class="mb-4">These activities are designed to enrich the learning experience and help students develop well-rounded skills. Through these engagements, we aim to instill values of teamwork, discipline, and cultural appreciation.</p>
                        <div class="row g-4 align-items-center">
                            <div class="col-sm-6">
                                <a class="btn btn-primary rounded-pill py-3 px-5" href="<?php echo e(route('allGallary')); ?>">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 about-img wow fadeInUp" data-wow-delay="0.5s">
                        <div class="row">
                            <div class="col-12 text-center">
                                <img class="img-fluid w-75 rounded-circle bg-light p-3" src="frontend/img/assets/img4.png" alt="">
                            </div>
                            <div class="col-6 text-start" style="margin-top: -150px;">
                                <img class="img-fluid w-100 rounded-circle bg-light p-3" src="frontend/img/assets/img5.png" alt="">
                            </div>
                            <div class="col-6 text-end" style="margin-top: -150px;">
                                <img class="img-fluid w-100 rounded-circle bg-light p-3" src="frontend/img/assets/img6.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About End -->

        <!-- Facilities Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">Facilities</h1>
                    <p>Our facilities include modern amenities designed to support student growth and well-being. These include spacious classrooms, well-equipped libraries, a dedicated video room, and state-of-the-art sports infrastructure. All areas are maintained to ensure a conducive environment for learning and development.</p>
                </div>
                <div class="row g-4">
                    <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="facility-item">
                            <div class="facility-icon bg-primary">
                                <span class="bg-primary"></span>
                                <i class="fa fa-bus-alt fa-3x text-primary"></i>
                                <span class="bg-primary"></span>
                            </div>
                            <div class="facility-text bg-primary">
                                <h3 class="text-primary mb-3">School Bus</h3>
                                <p class="mb-0">The school will provided transport facilities according to the specific routes.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="facility-item">
                            <div class="facility-icon bg-success">
                                <span class="bg-success"></span>
                                <i class="fa fa-futbol fa-3x text-success"></i>
                                <span class="bg-success"></span>
                            </div>
                            <div class="facility-text bg-success">
                                <h3 class="text-success mb-3">Playground</h3>
                                <p class="mb-0">SEC's sports societies actively foster young athletes and sportsmanship.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="facility-item">
                            <div class="facility-icon bg-warning">
                                <span class="bg-warning"></span>
                                <i class="fa fa-book fa-3x text-warning"></i>
                                <span class="bg-warning"></span>
                            </div>
                            <div class="facility-text bg-warning">
                                <h3 class="text-warning mb-3">Library</h3>
                                <p class="mb-0">Timely updated, accessible books to foster student reading habits.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.7s">
                        <div class="facility-item">
                            <div class="facility-icon bg-info">
                                <span class="bg-info"></span>
                                <i class="fa fa-chalkboard-teacher fa-3x text-info"></i>
                                <span class="bg-info"></span>
                            </div>
                            <div class="facility-text bg-info">
                                <h3 class="text-info mb-3">Language</h3>
                                <p class="mb-0">APSAC has a video room for students to watch cartoons and animated movies. </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row g-4 mt-4 align-items-center wow fadeInUp" data-wow-delay="0.8s">
                    <div class="text-center">
                        <a class="btn btn-primary rounded-pill py-3 px-5" href="<?php echo e(route('facilities')); ?>">Read More</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Facilities End -->


        <!-- Events Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">Events</h1>
                    <p>Our facilities include modern amenities designed to support student growth and well-being. These include spacious classrooms, well-equipped libraries, a dedicated video room, and state-of-the-art sports infrastructure.</p>
                </div>
                <div class="row bg-light rounded">
                    <div class="col-md-4 bg-primary">
                        <div class="wow fadeIn" data-wow-delay="0.5s">
                            <div class="h-100 d-flex flex-column justify-content-center p-5">
                                <h3 class="mb-4">Events</h3>
                                <p class="mb-4 text-white">What’s happening on campus</p>
                                <a class="btn btn-primary py-3 px-5" href="<?php echo e(route('events')); ?>">All Events<i class="fa fa-arrow-right ms-2"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div id="eventCarousel" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                <?php $__empty_1 = true; $__currentLoopData = $events->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunkIndex => $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> <!-- Show events in chunks of 8 -->
                                    <div class="carousel-item <?php if($chunkIndex === 0): ?> active <?php endif; ?>">
                                        <div class="row">
                                            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-md-4 mb-4 pt-3"> <!-- Adjust size as per your design -->
                                                    <a href="<?php echo e(route('eventsById' , $event->id)); ?>">
                                                        <div class="card">
                                                            <img src="<?php echo e($event->image_urls[0]); ?>" class="card-img-top" alt="Event Image" height="150px">
                                                            <div class="card-body">
                                                                <h5 class="card-title"><?php echo e($event->name); ?></h5>
                                                                <p class="card-text text-dark"><?php echo e(Str::limit($event->description, 20)); ?></p>
                                                                <p class="text-secondary"><strong>Date:</strong> <?php echo e(\Carbon\Carbon::parse($event->event_date)->format('M d, Y')); ?></p>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </div>
                    
                            <!-- Controls -->
                            <button class="carousel-control-prev" type="button" data-bs-target="#eventCarousel" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#eventCarousel" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                    </div>                    
                </div>
            </div>
        </div>
        <!-- Facilities End -->




        <!-- Call To Action Start -->
        
        <!-- Call To Action End -->


        <!-- Classes Start -->
        
        <!-- Classes End -->


        <!-- Appointment Start -->
        
        <!-- Appointment End -->


        <!-- Team Start -->
        
        <!-- Team End -->


        <!-- Testimonial Start -->
        
        <!-- Testimonial End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shayanProject\UniWebsite\resources\views/frontend/index.blade.php ENDPATH**/ ?>