

<?php $__env->startSection('content'); ?>

        <!-- Page Header End -->
        <div class="container-xxl py-5 page-header position-relative mb-5">
            <div class="container py-5">
                <h1 class="display-2 text-white animated slideInDown mb-4">Administration</h1>
                <nav aria-label="breadcrumb animated slideInDown">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">Administration</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End -->


        <!-- About Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-12 wow fadeInUp" data-wow-delay="0.1s">
                        <h1 class="mb-4 text-center">Administration</h1>
                        <div class="row">
                            <?php $__empty_1 = true; $__currentLoopData = $administrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $administration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            
                                <div class="administrationBox col-md-12 mt-5 d-flex justify-content-start">
                                    <div class="w-25">
                                        <img src="/images/<?php echo e($administration->image); ?>" width="90%" class="rounded" height="250px" alt="imag">
                                    </div>
                                    <div class="w-75">
                                        <h4 class=""><?php echo e($administration->name); ?></h4>
                                        <p class="alignPara"><?php echo e($administration->detail); ?></p>
                                    </div>
                                </div>

                               
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>There are no Administration</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About End -->





        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.appTwo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shayanProject\UniWebsite\resources\views/frontend/administration.blade.php ENDPATH**/ ?>