<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>SEC</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="frontend/img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@600&family=Lobster+Two:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/css/lightbox.min.css" rel="stylesheet">


    <!-- Libraries Stylesheet -->
    <link href="<?php echo e(asset('frontend/lib/animate/animate.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="<?php echo e(asset('frontend/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('frontend/css/mediaQuery.css')); ?>" rel="stylesheet">
</head>

<body>
    <div class="container-fluid bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Navbar Start -->
        <nav class="navbar navbar-expand-lg backgrounNav navbar-dark px-4 px-lg-5 py-lg-0">
            <a href="<?php echo e(route('index')); ?>" class="navbar-brand w-25">
                
              <img src="/frontend/img/assets/logo3.png" alt="logo" class="logoImg">
            </a>
            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav mx-auto">
                    <a href="<?php echo e(route('index')); ?>" class="nav-item nav-link <?php echo e(Request::routeIs('index') ? 'active' : ''); ?>">Home</a>
                    <div class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle <?php echo e(Request::routeIs('about', 'principalMessage', 'missionVission', 'allAdministration', 'facilities', 'trustees') ? 'active' : ''); ?>" href="<?php echo e(route('about')); ?>">
                            About
                        </a>   
                        <div class="dropdown-menu rounded-0 rounded-bottom border-0 shadow-sm m-0">
                            <a href="<?php echo e(route('principalMessage')); ?>" class="dropdown-item <?php echo e(Request::routeIs('principalMessage') ? 'active' : ''); ?>">Principal Message</a>
                            <a href="<?php echo e(route('missionVission')); ?>" class="dropdown-item <?php echo e(Request::routeIs('missionVission') ? 'active' : ''); ?>">Vision & Mission</a>
                            <a href="<?php echo e(route('allAdministration')); ?>" class="dropdown-item <?php echo e(Request::routeIs('allAdministration') ? 'active' : ''); ?>">Administration</a>
                            <a href="<?php echo e(route('facilities')); ?>" class="dropdown-item <?php echo e(Request::routeIs('facilities') ? 'active' : ''); ?>">Facilities</a>
                            <a href="<?php echo e(route('trustees')); ?>" class="dropdown-item <?php echo e(Request::routeIs('trustees') ? 'active' : ''); ?>">Trustees</a>
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle <?php echo e(Request::routeIs('admisionPolicy', 'classes', 'howToApply', 'systemExam') ? 'active' : ''); ?>" data-bs-toggle="dropdown">Admission</a>
                        <div class="dropdown-menu rounded-0 rounded-bottom border-0 shadow-sm m-0">
                            <a href="<?php echo e(route('admisionPolicy')); ?>" class="dropdown-item <?php echo e(Request::routeIs('admisionPolicy') ? 'active' : ''); ?>">Admission Policy</a>
                            <a href="<?php echo e(route('scholarship')); ?>" class="dropdown-item <?php echo e(Request::routeIs('scholarship') ? 'active' : ''); ?>">Scholarships</a>
                            <a href="<?php echo e(route('classes')); ?>" class="dropdown-item <?php echo e(Request::routeIs('classes') ? 'active' : ''); ?>">Classes</a>
                            <a href="<?php echo e(route('howToApply')); ?>" class="dropdown-item <?php echo e(Request::routeIs('howToApply') ? 'active' : ''); ?>">How to Apply</a>
                            <a href="<?php echo e(route('systemExam')); ?>" class="dropdown-item <?php echo e(Request::routeIs('systemExam') ? 'active' : ''); ?>">System Of Examination</a>
                        </div>
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle <?php echo e(Request::routeIs('studentStar', 'studentTiming') ? 'active' : ''); ?>" data-bs-toggle="dropdown">Student</a>
                        <div class="dropdown-menu rounded-0 rounded-bottom border-0 shadow-sm m-0">
                            <a href="<?php echo e(route('studentStar')); ?>" class="dropdown-item <?php echo e(Request::routeIs('studentStar') ? 'active' : ''); ?>">Shining Stars</a>
                            <a href="<?php echo e(route('studentTiming')); ?>" class="dropdown-item <?php echo e(Request::routeIs('studentTiming') ? 'active' : ''); ?>">Timings</a>
                        </div>
                    </div>
                    <a href="<?php echo e(route('feeStructure')); ?>" class="nav-item nav-link <?php echo e(Request::routeIs('feeStructure') ? 'active' : ''); ?>">Fee Structure</a>
                    <a href="<?php echo e(route('allGallary')); ?>" class="nav-item nav-link <?php echo e(Request::routeIs('allGallary') ? 'active' : ''); ?>">Gallery</a>
                    <a href="<?php echo e(route('allCareer')); ?>" class="nav-item nav-link <?php echo e(Request::routeIs('allCareer') ? 'active' : ''); ?>">Career</a>
                    <a href="<?php echo e(route('contact')); ?>" class="nav-item nav-link <?php echo e(Request::routeIs('contact') ? 'active' : ''); ?>">Contact Us</a>
                    
                </div>
                
            </div>
        </nav>
        <!-- Navbar End -->


        <?php echo $__env->yieldContent('content'); ?>


        <!-- Footer Start -->
        <div class="container-fluid backgrounNav text-white-50 footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-lg-3 col-md-6">
                        <h3 class="text-white mb-4">Get In Touch</h3>
                        <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Sharif Complex, Jati Umrah, <span class="ms-4">Lahore</span></p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>042 378 60308-10</p>
                        <p class="mb-2"><i class="fa fa-envelope me-3"></i>hr@sharif.edu.pk</p>
                        <div class="d-flex pt-2">
                            
                            <a class="btn btn-outline-light btn-social" href="https://www.facebook.com/SharifEducationComplex" target="_blank"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-instagram"></i></a>
                            
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h3 class="text-white mb-4">Quick Links</h3>
                        <a class="btn btn-link text-white-50" href="<?php echo e(route('about')); ?>">About Us</a>
                        <a class="btn btn-link text-white-50" href="<?php echo e(route('contact')); ?>">Contact Us</a>
                        <a class="btn btn-link text-white-50" href="<?php echo e(route('admisionPolicy')); ?>">Admission</a>
                        <a class="btn btn-link text-white-50" href="">Privacy Policy</a>
                        <a class="btn btn-link text-white-50" href="">Terms & Condition</a>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h3 class="text-white mb-4">Photo Gallery</h3>
                        <div class="row g-2 pt-2">
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="/frontend/img/assets/img4.png" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="/frontend/img/assets/img5.png" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="/frontend/img/assets/img6.png" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="/frontend/img/assets/img9.png" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="/frontend/img/assets/img10.png" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="/frontend/img/assets/img12.png" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h3 class="text-white mb-4">Newsletter</h3>
                        
                        <div class="position-relative mx-auto" style="max-width: 400px;">
                            <input class="form-control bg-transparent w-100 py-3 ps-4 pe-5" type="text" placeholder="Your email">
                            <button type="button" class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">SignUp</button>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('frontend/lib/wow/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/lib/easing/easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/lib/waypoints/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.4/js/lightbox.min.js"></script>


    <!-- Template Javascript -->
    <script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>
</body>

</html><?php /**PATH E:\shayanProject\UniWebsite\resources\views/frontend/layout/appTwo.blade.php ENDPATH**/ ?>