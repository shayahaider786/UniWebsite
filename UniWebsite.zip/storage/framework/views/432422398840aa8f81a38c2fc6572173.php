

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Job Application</h1>
        
    </div>

    <!-- Content Row -->
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Job Application Table</h6>
                </div>
                
                <!-- Success Message -->
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <div class="mt-3 me-4">
                    <?php if($allApplications->isEmpty()): ?>
                        
                        <button type="button" class="btn btn-danger float-end" disabled>Delete All Data</button>
                    <?php else: ?>
                        <form action="<?php echo e(route('DeleteAllJobs')); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete all inter data?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger float-end">Delete All Data</button>
                        </form>
                    <?php endif; ?>
                </div>
                <!-- Table -->
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Name</th>
                                    <th>CV</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $allApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allApplication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($allApplication->job_title); ?></td>
                                        <td><?php echo e($allApplication->name); ?></td>
                                        <td>
                                            <?php if(!empty($allApplication->cv_path)): ?>
                                                <a href="<?php echo e(asset('storage/' . $allApplication->cv_path)); ?>" class="btn btn-primary" download>Download CV</a>
                                            <?php else: ?>
                                                No CV Uploaded
                                            <?php endif; ?>
                                        </td>                                                                               
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">no job applicaion found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shayanProject\UniWebsite\resources\views/backend/careers/jobApplication.blade.php ENDPATH**/ ?>