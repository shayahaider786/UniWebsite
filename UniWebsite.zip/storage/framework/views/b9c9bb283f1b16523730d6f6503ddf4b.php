

<?php $__env->startSection('content'); ?>

        <!-- Page Header End -->
        <div class="container-xxl py-5 page-header position-relative mb-5">
            <div class="container py-5">
                <h1 class="display-2 text-white animated slideInDown mb-4">Admision Policy</h1>
                <nav aria-label="breadcrumb animated slideInDown">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">Admision Policy</li>
                    </ol>
                </nav>
            </div>
        </div>
        <!-- Page Header End -->


         <!--school Adminsin  Start -->
         <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-12 wow  fadeInUp" data-wow-delay="0.1s">
                        <h1 class="mb-4 text-center">School Section</h1>
                        <div class="row">
                            <div class="col-md-12 ">
                                <table class="table table-bordered">
                                    <tr>
                                        <th><b>Play Group (Montessori)</b></th>
                                        <td class="text-center">General Interview</td>
                                    </tr>
                                    <tr>
                                        <th><b>Nursery To Three</b></th>
                                        <td class="text-center">Mathematics, Urdu, Eng (Objective) obtained at least 50% marks in all subjects</td>
                                    </tr>
                                    <tr>
                                        <th class="w-50"><b>Four- Matric or O Level</b></th>
                                        <td class="text-center w-50">Mathematics, Science, English, Urdu (Subjective) obtained at least 50% marks in all subjects</td>
                                    </tr>
                                  </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 wow  fadeInUp" data-wow-delay="0.1s">
                        <h2 class="mb-4">Documents Required for Admission:</h2>
                        <div class="row">
                            <div class="col-md-12">
                                <ul>
                                    <li>4 snaps (Passport size with white background)</li>
                                    <li>Copy of B.Form/smart card</li>
                                    <li>ID card copy Father & Mother</li>
                                    <li>Previous School Leaving Certificate</li>
                                    <li>Previous Result Card</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- school Adminsin End -->

         <!--school Adminsin  Start -->
         
        <!-- school Adminsin End -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.appTwo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shayanProject\UniWebsite\resources\views/frontend/admisionPolicy.blade.php ENDPATH**/ ?>