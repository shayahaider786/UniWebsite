

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
        
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Matric Data</h1>
        <a href="<?php echo e(route('matricAdmisionExport')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-success shadow-sm">Export to CSV</a>
        
    </div>

    <!-- Content Row -->
    <div class="row">
        <!-- DataTales Example -->
        <div class="col-md-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Matric Table</h6>
                </div>
              
                <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                    <div class="alert alert-success" role="alert"> <?php echo e($value); ?> </div>
                <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
                <div class="mt-3 me-4">
                    <?php if($matricDatas->isEmpty()): ?>
                        
                        <button type="button" class="btn btn-danger float-end" disabled>Delete All Data</button>
                    <?php else: ?>
                        <form action="<?php echo e(route('matricDeleteAll')); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete all matric data?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger float-end">Delete All Data</button>
                        </form>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Father Name</th>
                                    <th>Mother Name</th>
                                    <th>Date Of Birth</th>
                                    <th>Class</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $matricDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matricData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($matricData->name); ?></td>
                                        <td><?php echo e($matricData->father_name); ?></td>
                                        <td><?php echo e($matricData->mother_name); ?></td>
                                        <td><?php echo e($matricData->dob); ?></td>
                                        <td><?php echo e($matricData->class); ?></td>
                                        <td>
                                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('matricDataShow', $matricData->id)); ?>"><i class="fa-solid fa-pen-to-square"></i> show</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5">There are no data.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shayanProject\UniWebsite\resources\views/backend/matricData.blade.php ENDPATH**/ ?>